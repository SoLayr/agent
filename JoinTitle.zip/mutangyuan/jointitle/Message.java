/*  1:   */ package mutangyuan.jointitle;
/*  2:   */ 
/*  3:   */ import org.bukkit.configuration.file.FileConfiguration;
/*  4:   */ import org.bukkit.entity.Player;
/*  5:   */ import org.bukkit.event.EventHandler;
/*  6:   */ import org.bukkit.event.Listener;
/*  7:   */ import org.bukkit.event.player.PlayerJoinEvent;
/*  8:   */ 
/*  9:   */ public class Message
/* 10:   */   implements Listener
/* 11:   */ {
/* 12:   */   @EventHandler
/* 13:   */   public void onPlayerJoin(PlayerJoinEvent evt)
/* 14:   */   {
/* 15:12 */     Player p = evt.getPlayer();
/* 16:13 */     for (int i1 = 0; i1 < 20; i1++) {
/* 17:14 */       p.sendMessage("");
/* 18:   */     }
/* 19:16 */     for (int i = 1; i < 7; i++) {
/* 20:17 */       p.sendMessage(Main.plugin.getConfig().getString("JoinMessage" + i).replace("&", "§"));
/* 21:   */     }
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\Administrator\Desktop\JoinTitleV0.0.5.jar
 * Qualified Name:     mutangyuan.jointitle.Message
 * JD-Core Version:    0.7.0.1
 */