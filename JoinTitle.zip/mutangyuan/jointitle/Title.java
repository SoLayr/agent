/*  1:   */ package mutangyuan.jointitle;
/*  2:   */ 
/*  3:   */ import org.bukkit.configuration.file.FileConfiguration;
/*  4:   */ import org.bukkit.entity.Player;
/*  5:   */ import org.bukkit.event.EventHandler;
/*  6:   */ import org.bukkit.event.Listener;
/*  7:   */ import org.bukkit.event.player.PlayerJoinEvent;
/*  8:   */ 
/*  9:   */ public class Title
/* 10:   */   implements Listener
/* 11:   */ {
/* 12:   */   @EventHandler
/* 13:   */   public void onPlayerJoin(PlayerJoinEvent evt)
/* 14:   */   {
/* 15:13 */     Player p = evt.getPlayer();
/* 16:14 */     p.sendTitle(Main.plugin.getConfig().getString("JoinTitle1").replace("&", "§"), Main.plugin.getConfig().getString("JoinTitle2").replace("&", "§"));
/* 17:   */   }
/* 18:   */ }


/* Location:           C:\Users\Administrator\Desktop\JoinTitleV0.0.5.jar
 * Qualified Name:     mutangyuan.jointitle.Title
 * JD-Core Version:    0.7.0.1
 */