/*  1:   */ package mutangyuan.jointitle;
/*  2:   */ 
/*  3:   */ import org.bukkit.Server;
/*  4:   */ import org.bukkit.command.ConsoleCommandSender;
/*  5:   */ import org.bukkit.plugin.PluginManager;
/*  6:   */ import org.bukkit.plugin.java.JavaPlugin;
/*  7:   */ 
/*  8:   */ public class Main
/*  9:   */   extends JavaPlugin
/* 10:   */ {
/* 11:   */   public static Main plugin;
/* 12:   */   
/* 13:   */   public void onEnable()
/* 14:   */   {
/* 15:10 */     plugin = this;
/* 16:11 */     getServer().getConsoleSender().sendMessage("§eJoinTitle >>> §7插件成功加载！");
/* 17:12 */     saveDefaultConfig();
/* 18:13 */     getServer().getPluginManager().registerEvents(new Title(), this);
/* 19:14 */     getServer().getPluginManager().registerEvents(new Message(), this);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void onDisable()
/* 23:   */   {
/* 24:18 */     getServer().getConsoleSender().sendMessage("§eJoinTitle >>> §7插件成功卸载！");
/* 25:   */   }
/* 26:   */ }


/* Location:           C:\Users\Administrator\Desktop\JoinTitleV0.0.5.jar
 * Qualified Name:     mutangyuan.jointitle.Main
 * JD-Core Version:    0.7.0.1
 */